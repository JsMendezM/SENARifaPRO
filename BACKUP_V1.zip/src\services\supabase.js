import { createClient } from '@supabase/supabase-js';

// ============================================================================
// CONFIGURACIÓN DE SUPABASE (BASE DE DATOS Y AUTENTICACIÓN)
// ============================================================================
// Supabase es una alternativa a Firebase, de código abierto e ideal para Startups.
// Proporciona tanto la base de datos PostgreSQL como el sistema de inicio de sesión.
//
// TODO: El usuario (tú o tu equipo) debe reemplazar estas variables con las reales 
// de su proyecto de Supabase.
// Se obtienen en supabase.com -> Tu Proyecto -> Settings -> API
const supabaseUrl = 'https://hpghssluyzxpdlgqhcut.supabase.co';
const supabaseAnonKey = 'sb_publishable_7RIvryHY2lwIAV9mK1ZKCg_yEjRi_ru';

/**
 * Cliente global de Supabase.
 * Exportamos esta variable `supabase` para que cualquier parte de la aplicación
 * (Login, Dashboard, Grilla pública) pueda interactuar de forma segura con la Base de Datos.
 */
export const supabase = createClient(supabaseUrl, supabaseAnonKey);
