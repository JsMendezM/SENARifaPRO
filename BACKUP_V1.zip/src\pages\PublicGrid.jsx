import React, { useEffect, useState } from 'react';
import { useParams, Link } from 'react-router-dom';
import { supabase } from '../services/supabase';
import { Gift, Car, Smartphone, Banknote, MonitorPlay, ArrowLeft, CheckCircle2, Lock, Trophy, ShieldCheck, CreditCard } from 'lucide-react';

/**
 * Grilla Pública (Vista para los participantes).
 * Esta es la pantalla que ve el cliente cuando se le pasa el enlace.
 */
function PublicGrid() {
    const { id } = useParams(); // Obtenemos el ID de la rifa de la URL

    // Estado de la Rifa
    const [rifa, setRifa] = useState(null);
    const [tickets, setTickets] = useState([]); // Nuevo: Boletas ya tomadas
    const [organizerProfile, setOrganizerProfile] = useState(null); // Nuevo: Datos Anti-Fraude
    const [isLoading, setIsLoading] = useState(true);
    const [error, setError] = useState('');

    // Estado del número seleccionado por el usuario
    const [selectedNumber, setSelectedNumber] = useState(null);
    const [buyerName, setBuyerName] = useState('');
    const [buyerPhone, setBuyerPhone] = useState('');
    const [isReserving, setIsReserving] = useState(false);
    const [showSuccess, setShowSuccess] = useState(false);

    // Para el demo interactivo, generaremos un arreglo de 100 números (del 00 al 99).
    const numbers = Array.from({ length: 100 }, (_, i) => i.toString().padStart(2, '0'));

    // Lista de Loterías de Colombia para formatear visualmente
    const lotteries = [
        { id: 'baloto', label: 'Baloto' },
        { id: 'cruz_roja', label: 'Lotería Cruz Roja' },
        { id: 'bogota', label: 'Lotería de Bogotá' },
        { id: 'medellin', label: 'Lotería de Medellín' },
        { id: 'valle', label: 'Lotería del Valle' },
        { id: 'boyaca', label: 'Lotería de Boyacá' },
        { id: 'chontico', label: 'Chontico (Día/Noche)' },
        { id: 'dorado', label: 'El Dorado' },
        { id: 'cafeterito', label: 'Cafeterito' },
        { id: 'paisita', label: 'Paisita' }
    ];

    const fetchRifaDetails = async () => {
        setIsLoading(true);
        try {
            // 1. Cargar la configuración de la Rifa
            const { data: rifaData, error: rifaError } = await supabase
                .from('rifas')
                .select('*')
                .eq('id', id)
                .single();

            if (rifaError) throw rifaError;
            if (!rifaData) throw new Error("Rifa no encontrada");

            setRifa(rifaData);

            // 2. Cargar perfil del organizador
            const { data: profileData } = await supabase
                .from('profiles')
                .select('full_name, whatsapp_number, payment_info, is_verified')
                .eq('id', rifaData.organizer_id)
                .single();

            if (profileData) {
                setOrganizerProfile(profileData);
            }

            // 3. Cargar los números ya apartados de esta rifa
            const { data: ticketsData, error: ticketsError } = await supabase
                .from('tickets')
                .select('*')
                .eq('rifa_id', id);

            if (ticketsError) throw ticketsError;
            setTickets(ticketsData || []);

        } catch (err) {
            console.error("Error cargando la rifa:", err);
            setError(err.message);
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        fetchRifaDetails();
    }, [id]);

    const renderIcon = (iconString) => {
        switch (iconString) {
            case 'car': return <Car size={48} color="var(--primary-color)" />;
            case 'smartphone': return <Smartphone size={48} color="var(--primary-color)" />;
            case 'banknote': return <Banknote size={48} color="var(--primary-color)" />;
            case 'monitor': return <MonitorPlay size={48} color="var(--primary-color)" />;
            case 'gift':
            default: return <Gift size={48} color="var(--primary-color)" />;
        }
    };

    const handleSelectNumber = (num) => {
        setSelectedNumber(num);
        setShowSuccess(false);
    };

    const handleReserveAndPay = async (e) => {
        e.preventDefault();
        setIsReserving(true);

        try {
            // Guardar en la DB
            const { error: reserveError } = await supabase.from('tickets').insert([{
                rifa_id: rifa.id,
                number: selectedNumber,
                buyer_name: buyerName,
                buyer_phone: buyerPhone,
                status: 'reserved'
            }]);

            if (reserveError) {
                // Si el error es de UNIQUE Constraint (El número ya se tomó hace un milisegundo)
                if (reserveError.code === '23505') {
                    throw new Error("¡Lo sentimos! Alguien más acaba de separar este número exactamente al mismo tiempo que tú. Por favor elige otro.");
                }
                throw reserveError;
            }

            // Actualizar la grilla local inmediatamente sin recargar
            setTickets([...tickets, { number: selectedNumber, status: 'reserved', buyer_name: buyerName }]);
            setShowSuccess(true);

        } catch (err) {
            console.error("Error reservando:", err);
            alert(err.message || "Ocurrió un error separando tu boleta.");
        } finally {
            setIsReserving(false);
        }
    };

    if (isLoading) return <div style={{ textAlign: 'center', padding: '4rem', color: 'var(--text-muted)' }}>Cargando grilla...</div>;

    if (error) return (
        <div style={{ textAlign: 'center', padding: '4rem' }}>
            <h2>🚫 Rifa no encontrada</h2>
            <p style={{ color: 'var(--text-muted)' }}>{error}</p>
            <Link to="/" style={{ color: 'var(--primary-color)', marginTop: '1rem', display: 'inline-block' }}>Volver al inicio</Link>
        </div>
    );

    return (
        <div className="container" style={{ padding: '2rem 1rem', maxWidth: '800px' }}>

            {/* Aviso de Modo Prueba si la rifa no ha sido activada por el organizador */}
            {!rifa.is_paid && (
                <div style={{ backgroundColor: 'rgba(255, 100, 100, 0.1)', border: '1px solid #ff6b6b', borderRadius: '8px', padding: '1rem', marginBottom: '2rem', textAlign: 'center' }}>
                    <p style={{ color: '#ff6b6b', fontWeight: 'bold', margin: 0 }}>⚠️ MODO DE PRUEBA ACTIVO</p>
                    <p style={{ fontSize: '0.85rem', color: 'var(--text-muted)', margin: '0.5rem 0 0 0' }}>El organizador aún no ha activado los pagos de esta rifa. Esta es una vista previa de cómo la verá el cliente.</p>
                </div>
            )}

            {/* Cabecera Pública de la Rifa */}
            <header style={{ textAlign: 'center', marginBottom: '2rem', animation: 'fadeIn 0.5s ease-out' }}>
                <div style={{ display: 'flex', justifyContent: 'center', marginBottom: '1rem' }}>
                    {renderIcon(rifa.icon)}
                </div>
                <h1 className="premium-gradient-text" style={{ fontSize: '2.5rem', marginBottom: '0.5rem' }}>
                    {rifa.title}
                </h1>
                <p style={{ fontSize: '1.2rem', color: 'var(--text-main)', maxWidth: '600px', margin: '0 auto' }}>
                    {rifa.description}
                </p>

                {rifa.play_date && (
                    <div style={{ marginTop: '1rem' }}>
                        <span style={{ fontSize: '0.9rem', color: 'var(--primary-color)', backgroundColor: 'rgba(34, 211, 238, 0.1)', padding: '0.5rem 1rem', borderRadius: '50px', border: '1px solid rgba(34, 211, 238, 0.2)' }}>
                            🎉 Juega con <strong>{lotteries.find(l => l.id === rifa.lottery_type)?.label || rifa.lottery_type}</strong> el {new Date(rifa.play_date + 'T00:00:00').toLocaleDateString()}
                        </span>
                    </div>
                )}

                <div style={{ display: 'inline-block', backgroundColor: 'var(--bg-secondary)', padding: '0.5rem 1.5rem', borderRadius: '20px', marginTop: '1.5rem', border: '1px solid rgba(255,255,255,0.05)' }}>
                    <p style={{ color: 'var(--text-muted)', margin: 0, fontWeight: 'bold' }}>
                        Valor boleta: <span style={{ color: 'var(--primary-color)' }}>${parseFloat(rifa.ticket_price).toLocaleString('es-CO')} COP</span>
                    </p>
                </div>
            </header>

            {/* Formulario/Modal Flotante de Compra (AHORA ES UN POP-UP) */}
            {selectedNumber && !showSuccess && (
                <div className="modal-overlay" onClick={() => { setShowSuccess(false); setSelectedNumber(null); }}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()}>
                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '1rem' }}>
                            <h3 style={{ margin: 0, fontSize: '1.25rem' }}>
                                Apartar el número <strong style={{ color: 'var(--primary-color)', fontSize: '1.5rem' }}>{selectedNumber}</strong>
                            </h3>
                            <button onClick={() => { setShowSuccess(false); setSelectedNumber(null); }} style={{ background: 'none', border: 'none', color: 'var(--text-muted)', cursor: 'pointer', fontSize: '1.5rem', lineHeight: 1 }}>
                                &times;
                            </button>
                        </div>

                        <form onSubmit={handleReserveAndPay} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
                            <div>
                                <input type="text" className="input-field" placeholder="Tu Nombre Completo" required value={buyerName} onChange={(e) => setBuyerName(e.target.value)} />
                            </div>
                            <div>
                                <input type="tel" className="input-field" placeholder="Tu WhatsApp (Ej. 300...)" required value={buyerPhone} onChange={(e) => setBuyerPhone(e.target.value)} />
                            </div>

                            <div style={{ display: 'flex', gap: '1rem', marginTop: '0.5rem' }}>
                                <button type="submit" className="btn btn-primary" style={{ flex: 1, justifyContent: 'center', padding: '1rem', fontSize: '1.1rem' }} disabled={isReserving}>
                                    {isReserving ? 'Procesando...' : `Confirmar y Pagar Boleta`}
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            )}

            {/* Mensaje de Compra Exitosa (Fase Demostración - AHORA ES UN POP-UP) */}
            {showSuccess && (
                <div className="modal-overlay" onClick={() => { setShowSuccess(false); setSelectedNumber(null); }}>
                    <div className="modal-content" onClick={(e) => e.stopPropagation()} style={{ textAlign: 'center', borderColor: '#10b981' }}>
                        <CheckCircle2 color="#10b981" size={48} style={{ margin: '0 auto 1rem auto' }} />
                        <h3 style={{ color: '#10b981', margin: '0 0 0.5rem 0' }}>¡Número {selectedNumber} Reservado!</h3>
                        <p style={{ color: 'var(--text-main)', margin: '0 0 1rem 0' }}>Para completarlo deberás realizar el pago por los medios que el organizador indica.</p>

                        {/* Mostrar Métodos de Pago aquí si existen */}
                        {organizerProfile?.payment_info && (
                            <div style={{ backgroundColor: 'rgba(34, 211, 238, 0.05)', padding: '1rem', borderRadius: '8px', border: '1px solid rgba(34, 211, 238, 0.2)', marginBottom: '1.5rem', textAlign: 'left' }}>
                                <strong style={{ fontSize: '0.9rem', display: 'flex', alignItems: 'center', gap: '6px', marginBottom: '0.5rem' }}><CreditCard size={18} /> Opciones de Pago:</strong>
                                <p style={{ fontSize: '0.9rem', margin: 0, whiteSpace: 'pre-wrap', color: 'var(--text-main)' }}>{organizerProfile.payment_info}</p>
                            </div>
                        )}

                        <button onClick={() => { setShowSuccess(false); setSelectedNumber(null); }} className="btn btn-secondary" style={{ marginTop: '0.5rem', width: '100%', justifyContent: 'center' }}>
                            Cerrar y ver grilla
                        </button>
                    </div>
                </div>
            )}

            {/* Explicación Sencilla */}
            {!selectedNumber && !showSuccess && !rifa.winning_number && (
                <div className="card" style={{ marginBottom: '2rem', textAlign: 'center', backgroundColor: 'rgba(34, 211, 238, 0.05)', borderColor: 'rgba(34, 211, 238, 0.2)' }}>
                    <p style={{ margin: 0 }}>
                        {rifa.is_paid
                            ? "👇 Toca un número libre en la grilla para apartarlo y pagarlo a tu nombre."
                            : "⚠️ MODO DEMO: Esta rifa aún no ha sido activada por el organizador. Las compras están deshabilitadas."}
                    </p>
                </div>
            )}

            {/* Información del Organizador (Anti-Fraude) */}
            {organizerProfile && (
                <div className="card" style={{ marginBottom: '2rem', display: 'flex', flexDirection: 'column', gap: '1rem', border: '1px solid rgba(16, 185, 129, 0.2)', backgroundImage: 'linear-gradient(to right, rgba(16, 185, 129, 0.05), transparent)' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
                        <ShieldCheck size={24} color="#10b981" />
                        <h3 style={{ margin: 0, fontSize: '1.2rem', color: '#10b981' }}>Organizador de la Rifa</h3>
                    </div>
                    <div style={{ display: 'flex', flexWrap: 'wrap', gap: '1rem', justifyContent: 'space-between', alignItems: 'center' }}>
                        <div>
                            <p style={{ margin: '0 0 0.25rem 0', color: 'var(--text-muted)', fontSize: '0.85rem' }}>Nombre del Responsable</p>
                            <p style={{ margin: 0, fontWeight: 'bold' }}>{organizerProfile.full_name || 'No proporcionado'}</p>
                        </div>
                        {organizerProfile.whatsapp_number && (
                            <div>
                                <a href={`https://wa.me/${organizerProfile.whatsapp_number.replace(/\D/g, '')}`} target="_blank" rel="noopener noreferrer" className="btn btn-secondary" style={{ padding: '0.25rem 0.5rem', backgroundColor: '#25D366', color: '#fff', border: 'none', fontWeight: 'bold', gap: '4px' }}>
                                    📱 Contactar por WhatsApp
                                </a>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Si ya hay un ganador, mostrar la celebración destacada */}
            {rifa.winning_number && (
                <div style={{ backgroundColor: 'rgba(16, 185, 129, 0.15)', border: '2px solid #10b981', borderRadius: '12px', padding: '2rem', marginBottom: '2rem', textAlign: 'center', animation: 'pulse 2s infinite' }}>
                    <h2 style={{ color: '#10b981', fontSize: '2rem', margin: '0 0 1rem 0', display: 'flex', justifyContent: 'center', alignItems: 'center', gap: '10px' }}>
                        <Trophy size={40} /> ¡TENEMOS UN GANADOR! <Trophy size={40} />
                    </h2>
                    <p style={{ color: 'var(--text-main)', fontSize: '1.2rem', marginBottom: '1rem' }}>El número afortunado del sorteo fue:</p>
                    <div style={{ fontSize: '4.5rem', fontWeight: 'bold', color: '#10b981', textShadow: '0 0 20px rgba(16, 185, 129, 0.5)' }}>
                        {rifa.winning_number}
                    </div>
                </div>
            )}

            {/* La Grilla de 00-99 */}
            <div style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(60px, 1fr))',
                gap: '10px',
                opacity: selectedNumber || showSuccess ? 0.3 : 1, // Opacar si hay un número seleccionado
                pointerEvents: selectedNumber || showSuccess || rifa.winning_number || !rifa.is_paid ? 'none' : 'auto', // Deshabilitar clics si hay ganador, comprando, o no está pagada
                transition: 'all 0.3s ease'
            }}>
                {numbers.map((num) => {
                    // Verificar si el ticket ya está tomado en la base de datos
                    const ticketData = tickets.find(t => t.number === num);
                    const isTaken = !!ticketData;
                    const isWinner = rifa.winning_number === num;

                    return (
                        <button
                            key={num}
                            onClick={() => !isTaken && handleSelectNumber(num)}
                            className="btn"
                            disabled={isTaken || rifa.winning_number}
                            style={{
                                backgroundColor: isWinner ? '#10b981' : (isTaken ? 'rgba(255, 107, 107, 0.1)' : 'var(--bg-tertiary)'),
                                border: isWinner ? '2px solid #fff' : (isTaken ? '1px solid rgba(255, 107, 107, 0.3)' : '1px solid rgba(255,255,255,0.1)'),
                                padding: '1rem 0',
                                fontSize: '1.2rem',
                                fontWeight: 'bold',
                                borderRadius: '8px',
                                cursor: isTaken || rifa.winning_number ? 'not-allowed' : 'pointer',
                                color: isWinner ? '#fff' : (isTaken ? '#ff6b6b' : 'var(--text-main)'),
                                justifyContent: 'center',
                                transition: 'all 0.2s ease',
                                transform: isWinner ? 'scale(1.15)' : 'scale(1)',
                                zIndex: isWinner ? 10 : 1,
                                boxShadow: isWinner ? '0 0 25px rgba(16, 185, 129, 0.8)' : 'none'
                            }}
                            onMouseEnter={(e) => {
                                if (!isTaken && !rifa.winning_number) {
                                    e.target.style.backgroundColor = 'var(--primary-color)';
                                    e.target.style.color = '#000';
                                    e.target.style.transform = 'scale(1.05)';
                                }
                            }}
                            onMouseLeave={(e) => {
                                if (!isTaken && !rifa.winning_number) {
                                    e.target.style.backgroundColor = 'var(--bg-tertiary)';
                                    e.target.style.color = 'var(--text-main)';
                                    e.target.style.transform = 'scale(1)';
                                }
                            }}
                            title={isWinner ? '¡NÚMERO GANADOR!' : (isTaken ? `Separado por ${ticketData.buyer_name}` : 'Click para apartar')}
                        >
                            {isWinner ? <><Trophy size={16} style={{ marginRight: '2px' }} /> {num}</> : (isTaken ? <Lock size={20} /> : num)}
                        </button>
                    );
                })}
            </div>

            <div style={{ textAlign: 'center', marginTop: '3rem', paddingBottom: '2rem' }}>
                <Link to="/dashboard" style={{ color: 'var(--text-muted)', display: 'inline-flex', alignItems: 'center', gap: '0.5rem', textDecoration: 'none' }}>
                    <ArrowLeft size={16} /> Volver al panel de control
                </Link>
            </div>

        </div>
    );
}

export default PublicGrid;
